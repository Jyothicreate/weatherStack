package com.weatherstack.dto;

public class Location {

	   private String name;

	   private double lat;

	   private double lon;

	   private String country;

	   private String timezone_id;

	 public String getName() {

	  return name;

	 }

	 public void setName(String name) {

	  this.name = name;

	 }

	 public double getLat() {

	  return lat;

	 }

	 public void setLat(double lat) {

	  this.lat = lat;

	 }

	 public double getLon() {

	  return lon;

	 }

	 public void setLon(double lon) {

	  this.lon = lon;

	 }

	 public String getCountry() {

	  return country;

	 }

	 public void setCountry(String country) {

	  this.country = country;

	 }

	 public String getTimezone_id() {

	  return timezone_id;

	 }

	 public void setTimezone_id(String timezone_id) {

	  this.timezone_id = timezone_id;

	 }

	}


