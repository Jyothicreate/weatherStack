package com.weatherstack.dto;

public class weatherdto {

	 private Request request;

	 private Location location;

	 public Location getLocation() {

	 return location;

	 }

	 public void setLocation(Location location) {

	 this.location = location;

	 }

	 public Request getRequest() {

	 return request;

	 }

	 public void setRequest(Request request) {

	 this.request = request;

	 }

	}


