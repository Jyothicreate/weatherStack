package com.weatherstack.service;

import org.springframework.beans.factory.annotation.Value;

import org.springframework.stereotype.Service;

import org.springframework.web.client.RestTemplate;

import com.weatherstack.dto.weatherdto;

@Service

public class weatherServiceImpl{

 @Value("${weatherstack.api.key}")

  private String apiKey;

  @Value("${weatherstack.api.url}")

  private String apiUrl;

 private final RestTemplate restTemplate;

 public weatherServiceImpl(RestTemplate restTemplate) {

 this.restTemplate=restTemplate;

 }

 public weatherdto getWeatherDetails(String city) {

 String url = apiUrl + "?access_key=" + apiKey + "&query=" + city;

    return restTemplate.getForObject(url, weatherdto.class);

 }

}
