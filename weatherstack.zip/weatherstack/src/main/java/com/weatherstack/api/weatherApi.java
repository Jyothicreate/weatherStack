package com.weatherstack.api;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.weatherstack.dto.weatherdto;

import com.weatherstack.service.weatherServiceImpl;

@RestController

public class weatherApi {

 @Autowired

 weatherServiceImpl weatherServiceImpl;

 @GetMapping(value="/weather")

 public weatherdto getWeather(@RequestParam String city) {

 return weatherServiceImpl.getWeatherDetails(city);

 }

}
