package com.weatherstack;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WeatherstackApplicationTests {

	@Test
	void contextLoads() {
	}

}
