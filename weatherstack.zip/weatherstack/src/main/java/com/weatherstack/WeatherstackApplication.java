package com.weatherstack;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WeatherstackApplication {

	public static void main(String[] args) {
		SpringApplication.run(WeatherstackApplication.class, args);
	}

}
